﻿using System.Collections.Generic;
using IdentityServer3.Core.Models;
using IdentityServer3.Core;
using System.Linq;

namespace IdSrv
{
    static class Scopes
    {
        public static List<Scope> Get()
        {
            var scope = new List<Scope>
            {
               new Scope
            {
                Name = "myapi",
                Type = ScopeType.Resource,                
                Claims = new List<ScopeClaim>
                {
                    new ScopeClaim(Constants.ClaimTypes.Name),
                    new ScopeClaim(Constants.ClaimTypes.GivenName),
                    new ScopeClaim(Constants.ClaimTypes.FamilyName),
                    new ScopeClaim(Constants.ClaimTypes.Email),
                    new ScopeClaim(Constants.ClaimTypes.Role)                    
                }
            }
            };
            //StandardScopes.All.ToList().ForEach(a => a.Type = ScopeType.Resource);
            return scope;
        }
    }
}